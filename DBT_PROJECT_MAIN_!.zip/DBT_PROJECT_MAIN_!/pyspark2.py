from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, count, lit
from pyspark.sql.types import StructType, StringType
from kafka import KafkaProducer
import json
import mysql.connector

# Define schema
schema = StructType() \
    .add("user_id", StringType()) \
    .add("emoji_type", StringType()) \
    .add("timestamp", StringType())

# Initialize Spark session
spark = SparkSession.builder \
    .appName("EmojiAggregatorEvery2Sec") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# Kafka producer to send top emoji to 'highestemoji' topic
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Kafka stream source
kafka_stream = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "emojiaggregator") \
    .option("startingOffsets", "latest") \
    .load()

parsed_stream = kafka_stream.select(
    from_json(col("value").cast("string"), schema).alias("data")
).select("data.*")

# MySQL connection config (update credentials)
mysql_config = {
    "host": "localhost",
    "user": "amogh",
    "password": "yourpassword",
    "database": "emostream"
}

def process_batch(batch_df, batch_id):
    total_rows = batch_df.count()
    print(f"Batch {batch_id} contains {total_rows} rows")

    if total_rows == 0:
        print("No data in this batch.")
        return

    emoji_counts = batch_df.groupBy("emoji_type").count()

    total_emoji_count = emoji_counts.agg({"count": "sum"}).collect()[0][0]
    normalized_emoji_counts = emoji_counts.withColumn(
        "normalized_count", col("count") / lit(total_emoji_count)
    )

    emoji_results = normalized_emoji_counts.collect()

    # Print and send the most-used emoji via Kafka
    filtered_emojis = [row for row in emoji_results if row['normalized_count'] >= 0.26]

    if len(filtered_emojis) == 0:
        most_used_emoji = "NONE"
        print(f"Most used emoji: {most_used_emoji}\n")
    else:
        most_used_emoji = max(filtered_emojis, key=lambda x: (x['count']))
        emoji_to_send = most_used_emoji['emoji_type']
        print(f"Most used emoji: {emoji_to_send} "
              f"(Count: {most_used_emoji['count']}, Normalized: {most_used_emoji['normalized_count']:.2f})\n")

        producer.send('highestemoji', {'emoji_type': emoji_to_send})

    # ✅ Insert into MySQL
    try:
        connection = mysql.connector.connect(**mysql_config)
        cursor = connection.cursor()

        for row in emoji_results:
            query = """
                INSERT INTO aggregated_emoji_data (batch_id, emoji_type, count, normalized_count)
                VALUES (%s, %s, %s, %s)
            """
            try:
                cursor.execute(query, (
                    batch_id,  # Ensure batch_id is passed correctly
                    row['emoji_type'],
                    int(row['count']),
                    float(row['normalized_count'])
                ))
            except mysql.connector.IntegrityError as dup_err:
                print(f"❌ Duplicate entry error: {dup_err}")

        connection.commit()
        cursor.close()
        connection.close()
        print("✅ Data inserted into MySQL for batch", batch_id)

    except mysql.connector.Error as err:
        print("❌ MySQL error:", err)

# Stream trigger every 2 seconds
query = parsed_stream.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", "false") \
    .trigger(processingTime="2 seconds") \
    .foreachBatch(process_batch) \
    .start()

query.awaitTermination()
